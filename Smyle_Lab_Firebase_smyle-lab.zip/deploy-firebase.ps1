$ErrorActionPreference = "Stop"
Write-Host "Smyle Lab | Deploy Firebase" -ForegroundColor Cyan
if (-not (Get-Command firebase -ErrorAction SilentlyContinue)) {
  Write-Host "Instalando Firebase CLI..." -ForegroundColor Yellow
  npm install -g firebase-tools
}
firebase login
firebase use smyle-lab
firebase deploy --only hosting
Write-Host "Deploy concluído." -ForegroundColor Green
