# Publicar o Smyle Lab no Firebase Hosting

Project ID: `smyle-lab`
Repositório: `joaovsimoes/smyle-lab`

## Primeira publicação

1. Instale o Node.js, caso ainda não tenha.
2. Abra PowerShell nesta pasta.
3. Execute:

```powershell
npm install -g firebase-tools
firebase login
firebase use smyle-lab
firebase deploy --only hosting
```

Ao final, o Firebase mostrará a URL pública do Smyle Lab.

## GitHub

Os arquivos de configuração `.firebaserc` e `firebase.json` já estão preparados para o projeto `smyle-lab`.
Para manter GitHub e Firebase sincronizados, envie a pasta `public` e os demais arquivos deste pacote para o repositório `joaovsimoes/smyle-lab`.

Depois da primeira publicação, você pode configurar a integração do Firebase Hosting com GitHub para deploy automático da branch `main`.
